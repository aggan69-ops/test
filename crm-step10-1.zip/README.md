
# CRM Steg 10

Nu börjar systemet bli en riktig produkt.

Nytt:
- Outlook token storage (simulerad databas)
- Activity feed (mail, call, note)
- Telavox mock call logging
- Activity API

Detta är grunden för:
- kundhistorik
- säljlogg
- pipeline tracking
